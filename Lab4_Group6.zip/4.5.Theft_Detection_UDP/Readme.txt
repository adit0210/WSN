EXPLANATION OF PROTOCOL AND ITS WORKING

Since this is a theft detection application, consider a scenario where thefts occur when the environment becomes dark. Hence we've arbitrarily decided upon a THRESHOLD_VALUE.

If the value detected by the light sensor, is below this threshold value, consider it to be a scenario for a theft to occur. 
So the node transmits messages, to the the router node, as soon as it gets darker.

In other conditions, when the environment is sufficiently illuminated, the node does not transmit, remains inactive, thus saving power.

The message format used is a regular UDP packet, comprising of the sender node's ID, the sequence no of the packet, and the sensed light data.
