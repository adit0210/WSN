This source code works for 8-bit, 16-bit and 32-bit integers only.
